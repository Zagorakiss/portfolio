// This a way to add content for each project:

// I put an ID for each .cd-project-content

// ex: <div class="cd-project-content" id="project-1">

// After, I made a little change in JS:

//select a single project - open project-content panel
projectsContainer.on('click', '.cd-slider a', function(event) {
event.preventDefault();
if( jQuery(this).parent('li').next('li').is('.current') ) {
prevSides(projectsSlider);
} else if ( jQuery(this).parent('li').prev('li').prev('li').prev('li').is('.current')) {
nextSides(projectsSlider);
} else {
var id= jQuery(this).attr('href');
//singleProjectContent.addClass('is-visible');
jQuery(''+id+'').addClass('is-visible');